package hkmu.wadd.repository;

import hkmu.wadd.model.S265F;
import org.springframework.data.jpa.repository.JpaRepository;

public interface S265FRepository extends JpaRepository<S265F, Long> {
    // No changes needed here
    
}